package br.edu.fecap.ni2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

int numPedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void concluir(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        numPedido += 1;
        builder.setTitle("Pedido Realizado!");
        builder.setMessage("Numero de pedido: " + numPedido + 1830 );


        builder.setCancelable(false);

        builder.setIcon(android.R.drawable.dialog_holo_dark_frame);

        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

}